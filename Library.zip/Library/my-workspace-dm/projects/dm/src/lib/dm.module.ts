import { NgModule } from '@angular/core';
import { DMComponent } from './dm.component';



@NgModule({
  declarations: [
    DMComponent
  ],
  imports: [
  ],
  exports: [
    DMComponent
  ]
})
export class DMModule { }
