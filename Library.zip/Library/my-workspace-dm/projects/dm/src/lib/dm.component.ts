import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-DM',
  template: `
    <p>
      dm works!
    </p>
  `,
  styles: [
  ]
})
export class DMComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
