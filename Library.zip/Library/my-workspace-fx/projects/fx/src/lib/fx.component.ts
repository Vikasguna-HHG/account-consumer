import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-Fx',
  template: `
    <p>
      fx works!
    </p>
  `,
  styles: [
  ]
})
export class FxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
