import { NgModule } from '@angular/core';
import { FxComponent } from './fx.component';



@NgModule({
  declarations: [
    FxComponent
  ],
  imports: [
  ],
  exports: [
    FxComponent
  ]
})
export class FxModule { }
