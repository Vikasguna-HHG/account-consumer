import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FxModule } from 'fx'
import { DMModule } from 'dm'

@NgModule({
  declarations: [
    AppComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FxModule,
    DMModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
